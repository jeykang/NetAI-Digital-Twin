# Paper extras — 2026-07-22

Two optional paper deliverables, packaged standalone (kept out of
`PAPER_EXPERIMENTS_RESULTS.md` by request).

## 1. Registered-table query latency at the 13 TB tier  → `registered_count/`
Warmed `SELECT count(*)` on the largest **registered** (register-in-place) production
Bronze table, `nvidia_bronze.Radar` (**11,730,962,796 rows**, ~13 TB corpus):
**232 ms median of 5**, answered from Iceberg manifest statistics (no data scan).

Closes the scale-extrapolation gap: constant sub-second query latency holds for
*registered* tables at full production scale, not only the compact curation tables.
Full numbers + one-sentence paper reading in `registered_count/result.txt`;
reproduce with `registered_count/prod_count_bench.py`
(`spark-submit --packages org.apache.hadoop:hadoop-aws:3.3.4 prod_count_bench.py`).

## 2. Augmentation figures  → `augmentation_figures/`
Cosmos-Transfer1 day→adverse augmentation, real kept/rejected clips from the N=50 batch.

- **`fig_aug_before_after.png`** — label-preserving hardening: original (day) vs augmented
  for night / rain / fog (3 KEPT clips). Each panel annotated with the gate's YOLO
  agent-count and confidence deltas — detections drop (harder) with no invented agents.
- **`fig_hallucination_gate.png`** — the hallucination gate: a KEPT clip (added −1.67
  agents → label-preserving) vs a REJECTED clip (`2daf9698`: day 0.00 → aug 0.67 agents,
  invented a detection → rejected to preserve label validity).

Detection/confidence numbers are the YOLO values recorded in
`cosmos_augmentation/gate_report.json` (mean over frames {30,60,90}); the exact rows used
are in `augmentation_figures/exemplars.json`. Frames are #60/121. Source media (original +
augmented mp4s) live on the A100 cluster scratch (`/scratch/autodr_test/aug_test/`);
regenerate the figures with `augmentation_figures/build_figs.py` after pulling the mp4s
(needs `opencv-python-headless`, `numpy`, `pillow`).

### Clips used
| figure | clip | condition | verdict | day→aug agents | day→aug conf |
|---|---|---|---|---|---|
| before/after | `aa56971d` | night | KEPT | 2.33 → 0.67 | 0.379 → 0.406 |
| before/after | `31856298` | rain  | KEPT | 2.33 → 0.67 | 0.584 → 0.192 |
| before/after | `ad2948d2` | fog   | KEPT | 4.33 → 0.00 | 0.453 → 0.000 |
| hallucination | `aa56971d` | night | KEPT | 2.33 → 0.67 | 0.379 → 0.406 |
| hallucination | `2daf9698` | night | REJECTED | 0.00 → 0.67 | 0.000 → 0.309 |
