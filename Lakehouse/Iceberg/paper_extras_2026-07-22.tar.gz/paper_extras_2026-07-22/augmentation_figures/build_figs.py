"""Build two paper figures from pulled Cosmos-Transfer aug clips + gate_report.json:
 F1 before/after (label-preserving hardening, 3 conditions)
 F2 hallucination gate (kept vs rejected)
Detection/confidence deltas are the YOLO numbers recorded in gate_report.json."""
import cv2, json, numpy as np
from PIL import Image, ImageDraw, ImageFont

WD = "aug_media"
GATE = json.load(open("/home/netai/jeykang/NetAI-Digital-Twin/Lakehouse/Iceberg/cosmos_augmentation/gate_report.json"))
G = {(r["clip"], r["cond"]): r for r in GATE}
FR = 60
PW, PH = 480, 270
FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FR_ = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
fT = ImageFont.truetype(FB, 26); fL = ImageFont.truetype(FB, 20)
fC = ImageFont.truetype(FR_, 19); fCb = ImageFont.truetype(FB, 20); fF = ImageFont.truetype(FR_, 15)
INK = (31, 41, 55); MUT = (107, 114, 128); GRN = (26, 127, 55); RED = (180, 35, 24)
BORD = (208, 213, 221)


def frame(path, idx=FR):
    c = cv2.VideoCapture(path); c.set(cv2.CAP_PROP_POS_FRAMES, idx)
    ok, f = c.read(); c.release()
    if not ok:
        c = cv2.VideoCapture(path); ok, f = c.read(); c.release()
    f = cv2.cvtColor(cv2.resize(f, (PW, PH)), cv2.COLOR_BGR2RGB)
    return Image.fromarray(f)


def panel(img, toplabel, accent=INK):
    """image with a label bar above it."""
    canv = Image.new("RGB", (PW, PH + 30), "white"); d = ImageDraw.Draw(canv)
    d.text((4, 3), toplabel, font=fL, fill=accent)
    canv.paste(img, (0, 30))
    ImageDraw.Draw(canv).rectangle([0, 30, PW - 1, PH + 29], outline=BORD, width=2)
    return canv


def row(clip, cond, right_label, verdict=None, vcolor=INK):
    g = G[(clip, cond)]
    o = panel(frame(f"{WD}/orig/{clip}.mp4"), "original  (day)", MUT)
    a = panel(frame(f"{WD}/aug/{clip}_{cond}.mp4"), right_label, vcolor)
    gap = 16
    cap_h = 66
    W = PW * 2 + gap
    canv = Image.new("RGB", (W, o.height + cap_h), "white"); d = ImageDraw.Draw(canv)
    canv.paste(o, (0, 0)); canv.paste(a, (PW + gap, 0))
    # arrow between
    ay = 30 + PH // 2
    d.line([PW + 2, ay, PW + gap - 2, ay], fill=MUT, width=3)
    # caption
    cy = o.height + 6
    dc = (f"YOLO agents  {g['day_ndet']:.2f} -> {g['aug_ndet']:.2f}"
          f"     confidence  {g['day_conf']:.3f} -> {g['aug_conf']:.3f}")
    d.text((2, cy), dc, font=fC, fill=INK)
    if verdict:
        d.text((2, cy + 30), verdict, font=fCb, fill=vcolor)
    return canv


def _wrap(text, font, maxw, draw):
    words = text.split(); lines = []; cur = ""
    for w in words:
        t = (cur + " " + w).strip()
        if draw.textlength(t, font=font) <= maxw:
            cur = t
        else:
            lines.append(cur); cur = w
    if cur:
        lines.append(cur)
    return lines


def stack(title, rows, footer, out):
    gap = 22; pad = 24; th = 46
    meas = ImageDraw.Draw(Image.new("RGB", (10, 10)))
    CW = int(max(max(r.width for r in rows), meas.textlength(title, font=fT)))
    W = CW + pad * 2
    fl = _wrap(footer, fF, CW, meas)
    fh = 20 + len(fl) * 18
    H = th + pad + sum(r.height for r in rows) + gap * (len(rows) - 1) + fh
    canv = Image.new("RGB", (W, H), "white"); d = ImageDraw.Draw(canv)
    d.text((pad, 12), title, font=fT, fill=INK)
    d.line([pad, th, W - pad, th], fill=BORD, width=2)
    y = th + pad
    for r in rows:
        canv.paste(r, (pad, y)); y += r.height + gap
    fy = H - fh + 8
    for ln in fl:
        d.text((pad, fy), ln, font=fF, fill=MUT); fy += 18
    canv.save(out); print("wrote", out, canv.size)


# ---- Figure 1: label-preserving hardening ----
r1 = [row("aa56971d", "night", "night"),
      row("31856298", "rain", "rain"),
      row("ad2948d2", "fog", "fog")]
stack("Cosmos-Transfer1 augmentation: label-preserving hardening (day -> adverse)",
      r1,
      "frame 60/121; detections = mean YOLO agent count over frames {30,60,90} (gate_report.json). "
      "All three KEPT: harder (fewer/dimmer detections) with no invented agents.",
      "fig_aug_before_after.png")

# ---- Figure 2: hallucination gate ----
r2 = [row("aa56971d", "night", "night  (KEPT)", "added -1.67 agents -> label-preserving -> KEPT", GRN),
      row("2daf9698", "night", "night  (REJECTED)", "day 0.00 -> aug 0.67 agents: invented a detection -> REJECTED", RED)]
stack("Hallucination gate: rejecting augmentations that invent agents",
      r2,
      "Gate keeps a clip only if it is harder AND adds no agents (added <= 0). "
      "2daf9698 hallucinated an agent absent in the source -> rejected to preserve label validity.",
      "fig_hallucination_gate.png")
